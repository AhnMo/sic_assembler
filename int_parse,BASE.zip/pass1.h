#ifndef __PASS1_H__

#define __PASS1_H__

void pass1(char *src_filename, char *intermediate_filename, char *symbol_filename);

#endif
