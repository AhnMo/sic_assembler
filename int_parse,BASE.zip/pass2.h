#ifndef __PASS2_H__

#define __PASS2_H__

void pass2(char *intermediate_filename, char *symbol_filename, char *listing_filename, char *object_filename);

#endif
