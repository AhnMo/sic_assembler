#include "pass1.h"
//#include "pass2.h"

void main(void)
{
	char src_filename[10];
	char obj_filename[10];

	printf("\nEnter the input file name you want to assembly (*.asm):");
	scanf("%s", src_filename);
	fflush(stdin);
	printf("\nEnter the output file name you want(*.obj):");
	scanf("%s", obj_filename);
	fflush(stdin);

	pass1(src_filename);
	//pass2();
}